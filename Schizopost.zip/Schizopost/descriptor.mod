name="something"
supported_version="*"
path="mod\Schizopost"