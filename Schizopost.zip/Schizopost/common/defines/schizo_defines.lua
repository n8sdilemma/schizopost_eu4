-- schizopost crazy
NDefines.NGame.END_DATE = "9999.12.31"
NDefines.NCountry.MAX_TOLERANCE_HERETIC = 6
NDefines.NCountry.MAX_TOLERANCE_HEATHEN = 6

